#ifndef SOUNDMANAGER_H
#define SOUNDMANAGER_H

#include <irrKlang.h>
using namespace irrklang;

extern ISoundEngine* soundEngine;

#endif // SOUNDMANAGER_H